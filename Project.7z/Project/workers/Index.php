

<?php
	// command to be used for changing the item  quanitty 
//UPDATE `items` SET `type` = '1.5' WHERE `items`.`Id` = 1; 
	$server = "localhost";
	$username = "root";
	$password = "";
	$db = "practice_mangement";
	$t_name = "login";
	$connection = mysqli_connect($server, $username, $password, $db); 
?>



<!DOCTYPE html>
<html>
<head>
	<title>Workers</title>
	<link rel="stylesheet" type="text/css" href="../management/css/styles.css">
</head>
<body>
	<div class="mainbox"> 
			<div class="older1">
		<form class="search_box" method="post">
		
			<input type="input" name="search" class="searchbar"><br>
			<input type="submit" name="submit" class="botton3" value="search">
	
							</div>
			<?php 
				if(isset($_POST['submit'])){
					$search = 0;
					$output = '';
					$count = 1;
					$check = '';
					$row = '';
					$search = $_POST['search'];
					$search = preg_replace("#[^a-z]#i","", $search);
					$sql_command = "SELECT * FROM items WHERE name LIKE '%$search%'";
					$result = mysqli_query($connection, $sql_command);
					$rc = mysqli_num_rows($result);
					if($rc >=0)
					{
						echo ("<table class=\"first1\">");
					    echo "<tr>";
					    echo "<th>Id</th>";
					    echo "<th>Name</th>";
					    echo "<th>Quantity</th>";
					    echo "<th>Price</th>";
					    echo "</tr>";

						while($row = mysqli_fetch_assoc($result))
						{
							$Id = $row['Id'];
							$name = $row['name'];
							$quantity = $row['quantity'];
							$price = $row['price'];

							echo"<tr>";
						    echo "<td>$Id</td>";
						    echo "<td>$name</td>";
						    echo "<td>$quantity</td>";
						    echo "<td>$price</td>";
						    echo "</tr>";
						}

					}
				}

				?>	

					<div class="newer1">
						<input type="input" name="search1" class="searchbar"><br>
						<input type="submit" name="submity" class="botton4" value="Final">
					</div>
				<?php
				$output ='';
				if(isset($_POST['submity']))
				{
					$search1 = $_POST['search1'];
					$sql_command = "SELECT * FROM items WHERE Id = $search1";
					$result = mysqli_query($connection, $sql_command);
					while($row = mysqli_fetch_assoc($result))
					{

						$id = $row['Id'];
						if($id == $search1)
						{
								$id = $row['Id'];
								$p_name = $row['name'];
								$quantity = $row['quantity'];
								$price = $row['price'];
								$quantity -= 1;
								$sql_command = "UPDATE `items` SET `quantity` = '$quantity' WHERE `items`.`Id` = $id";
								mysqli_query($connection, $sql_command);
								$sql_command = "INSERT INTO `sales` (`sales_id`, `product_id`, `Product_name`, `Amount`) VALUES (NULL, $id, '$p_name', $price);";
								mysqli_query($connection, $sql_command);

						}				
					}
				}

			?>

			</form>

	</div>
</body>
</html>
