<?php
	$server = "localhost";
	$username = "root";
	$password = "";
	$db = "practice_mangement";
	$t_name = "login";
	$connection = mysqli_connect($server, $username, $password, $db); 
?>

<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="css/Styles.css">
	<title>Store Management</title>
</head>
<body>
	
	<form class="container" action="" method="post">
		<div class="box">
			<span class="hadd">Login</span><br>
			<span class="span1">User Id</span><br>
			<input class="userid" type="text" name="userid" placeholder="" required="">
			<br><span class="span2">User Password</span><br>
			<input class="password" type="password" name="userpw" placeholder="" required="">
			<br><input type="submit" class="btn" name="login" value="Login">
		</div>
	</form>

	



</body>
</html>

<?php
	$again = false; 
	$sql = "";
	$user_name = "";
	$password = "";

		if(isset($_POST['login']))
		{
			do{
					
				if(isset($_POST['login']))
				{
					if(isset($_POST['userid']) and isset($_POST['userpw']))
					{
						$user_name = $_POST['userid'];
						$password = $_POST['userpw'];
						$sql = "Select * from login where user_name = '$user_name';";
						$result = mysqli_query($connection, $sql);
						$rc = mysqli_num_rows($result);
						if($rc == 1)
						{
							$row = mysqli_fetch_assoc($result);
							if($row['user_name'] == $user_name)
							{
								if($row['password'] == $password)
								{
									$again = false;
									if($row['user'] == 1)
									{										header("Location: management/");
									}
									else
									{
										//worker
										header("Location: workers/");
									}
								}else{
									echo"<span class=\"usps\">!</span>";
									///password doesn't exit
								}

							}
							
						}
						else
						{
									echo"<span class=\"usname\">!</span>";
									

						}
					}
				}
			}while($again);
		}
	

?>