
<!DOCTYPE html>
<html>
<head>
	<title>test</title>
</head>
<body>
	<form action="#" method="post">
		<input type="submit" value="submit" name="submit">

	</form>
		<?php
			if(isset($_POST['submit'])){
				header("Location: ../workers/index.php");
			} 
			?>

</body>
</html>
