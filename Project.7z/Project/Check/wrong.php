<?php
	echo "wrong";
?>