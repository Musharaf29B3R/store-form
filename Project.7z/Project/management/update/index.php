<?php
	$server = "localhost";
	$username = "root";
	$password = "";
	$db = "practice_mangement";
	$t_name = "login";
	$connection = mysqli_connect($server, $username, $password, $db); 
?>
<!DOCTYPE html>
<html>
<head>
	<title>Update</title>
	<link rel="stylesheet" type="text/css" href="../css/styles.css">
</head>
<body>
	<div class="mainbox">
		<form action="#" method="POST">
			<div class="older">
				<span class="hadd">Search</span><br>
				</span><input type="text" name="searchbar1" class="searchbar">
				<input type="submit" name="submit" value="Search" class="botton">
				<?php
					if(isset($_POST['submit'])){
					$search = 0;
					$output = '';
					$count = 1;
					$check = '';
					$row = '';
					$search = $_POST['searchbar1'];
					$search = preg_replace("#[^a-z]#i","", $search);
					$sql_command = "SELECT * FROM items WHERE name LIKE '%$search%'";
					$result = mysqli_query($connection, $sql_command);
					$rc = mysqli_num_rows($result);
					if($rc >=0)
					{
						echo ("<table class=\"first1\">");
					    echo "<tr>";
					    echo "<th>Id</th>";
					    echo "<th>Name</th>";
					    echo "<th>Quantity</th>";
					    echo "<th>Price</th>";
					    echo "</tr>";

						while($row = mysqli_fetch_assoc($result))
						{
							$Id = $row['Id'];
							$name = $row['name'];
							$quantity = $row['quantity'];
							$price = $row['price'];

							echo"<tr>";
						    echo "<td>$Id</td>";
						    echo "<td>$name</td>";
						    echo "<td>$quantity</td>";
						    echo "<td>$price</td>";
						    echo "</tr>";
						}

					}
				}

				?>
			</div>
			<div class="newer">
				<span class="hadd">Update</span><br>
				<div><span class="a">Id</span><br><input type="text" name="searchbar2" class="searchbar"></div>
				<div><span class="a">Quantity</span><br><input type="text" name="searchbar3" class="searchbar"></div>
				<div><span class="a">Price</span><br><input type="text" name="searchbar4" class="searchbar"></div>
				<input type="submit" name="Final" value="Final" class="botton2">
				<?php
				if(isset($_POST['Final']))
				{
					$Id = $_POST['searchbar2'];
					$sql_command= "select * from items where Id = $Id";
					$result = mysqli_query($connection, $sql_command);
					$rc = mysqli_num_rows($result);
					$row = mysqli_fetch_assoc($result);

					if($rc == 1 and $row['Id'] == $Id){
						$quantity = $_POST['searchbar3'];
						$price = $_POST['searchbar4'];
						$sql_command = "UPDATE `items` SET `quantity` = $quantity, `price` = $price WHERE `items`.`Id` = $Id; ";
						mysqli_query($connection, $sql_command);
					}
				}
				?>
			</div>
		</form>
	</div>
</body>
</html>