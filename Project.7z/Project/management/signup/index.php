<?php
	$server = "localhost";
	$username = "root";
	$password = "";
	$db = "practice_mangement";
	$t_name = "login";
	$connection = mysqli_connect($server, $username, $password, $db); 
?>
<!DOCTYPE html>
<html>
<head>
	<title>Sign Up</title>
	<link rel="stylesheet" type="text/css" href="../css/styles.css">
</head>
<body>
	<form class="signupbox" action="" method="post">
		<div><span class="signup">Sign up</span></div>
		<span class="mark">&#10060;</span>

		<div class="test">
		
			<div>
				<span class="signups1">Username</span><br>
				<input type="text" name="username" class="signupun" required="">
			</div>

			<div>
				<span class="signups2">Password</span><br>
				<input type="text" name="password" class="signuppass" required="">
			</div>

			<div>
				<span class="signups3">Confirm Password</span><br>
				<input type="text" name="confirm" class="signupcrm" required="">
			</div>

			<div>
				<input type="submit" name="submit" class="signupsubmit" value="Sign UP" required="">
			</div>

		</div>
	</form>
</body>
</html>
<?php
	if(isset($_POST['submit']))
	{	
		$user_name = $_POST['username'];
		$sql_command= "Select * from login where user_name = '$username'";
		$result = mysqli_query($connection, $sql_command);
		$rc = mysqli_num_rows($result);
		if($rc == 0)
		{
			$password = $_POST['password'];
			$password2 = $_POST['confirm'];
			if($password == $password2)
			{
				$sql_command = "INSERT INTO `login` (`user_id`, `user`, `user_name`, `password`) VALUES (NULL, '0', '$user_name' , '$password')";
				mysqli_query($connection, $sql_command);
				header("Location: ../");
			}
			else
			{
				// mark that both password dont match
			}
		}
		else
		{
			// username already exist
		}
	}
?>
