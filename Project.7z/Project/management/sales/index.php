<?php
	$server = "localhost";
	$username = "root";
	$password = "";
	$db = "practice_mangement";
	$t_name = "login";
	$connection = mysqli_connect($server, $username, $password, $db); 
?>

<!DOCTYPE html>
<html>
<head>
	<title>Sales</title>
	<link rel="stylesheet" type="text/css" href="../css/styles.css">
</head>
<body>
	<div class="sales">
		<?php 
			$sql_command = "select * from sales;";
			$result = mysqli_query($connection, $sql_command);
			echo ("<table class=\"first1\">");
		    echo "<tr>";
		    echo "<th>Id</th>";
		    echo "<th>Name</th>";
		    echo "<th>Quantity</th>";
		    echo "<th>Price</th>";
		    echo "</tr>";
			while($row = mysqli_fetch_assoc($result))
			{

				$Id = $row['sales_id'];
				$p_id = $row['product_id'];
				$p_name = $row['Product_name'];
				$Amount = $row['Amount'];

				echo"<tr>";
			    echo "<td>$Id</td>";
			    echo "<td>$p_id</td>";
			    echo "<td>$p_name</td>";
			    echo "<td>$Amount</td>";
			    echo "</tr>";
			}

		?>
	</div>
</body>
</html>