<!DOCTYPE html>
<html>
<head>
	<title>management</title>
	<link rel="stylesheet" type="text/css" href="css/styles.css">

</head>
<body>
	<form class="box" action="" method="post">

		<div class="first"><input type="submit" name="signup" class="signup1" value="SignUp"></div>
		<div class="second"><input type="submit" name="update" class="update" value="Update"></div>
		<div class="third"><input type="submit" name="Sales" class="sales" value="Sales"></div>
	</form>
</body>
</html>

<?php
	if(isset($_POST['signup'])){
		header("Location: signup/");
	}
	if(isset($_POST['update'])){
		header("Location: update/");
	}
	if(isset($_POST['Sales'])){
		header("Location: sales/");		
	}
?>